.. highlight:: shell

=============
Contributors
=============

Development Lead
----------------

* John Preston
    * `Github <https://github.com/johnpreston>`__
    * `Keybase <https://keybase.io/johnpreston78>`__ |JohnPreston78PGP|

.. |JohnPreston78PGP| image:: https://img.shields.io/keybase/pgp/johnpreston78
