# SPDX-License-Identifier: MPL-2.0
# Copyright 2020-2024 John Mille <john@compose-x.io>


"""Top-level package for Compose-X Commons Lib."""

__author__ = """John Preston"""
__email__ = "john@compose-x.io"
__version__ = "1.4.12"
